import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class FirestoreService {
  final CollectionReference brand =
      FirebaseFirestore.instance.collection('brand');

  // Upload brand image
  Future<String?> _uploadImage(File imageFile) async {
    try {
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      Reference ref =
          FirebaseStorage.instance.ref().child('brand_logos/$fileName');
      UploadTask uploadTask = ref.putFile(imageFile);
      await uploadTask;
      String downloadUrl = await ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      print('Erreur lors du téléchargement de l\'image : $e');
      return null;
    }
  }

  // Add brand with image
  Future<void> addBrandWithImage(String id, String br, String imagePath) async {
    File imageFile = File(imagePath);
    String? imageUrl = await _uploadImage(imageFile);
    if (imageUrl != null) {
      await brand.add({
        'brand_id': id,
        'name': br,
        'logo_url': imageUrl,
      });
    } else {
      print('Erreur lors du téléchargement de l\'image.');
    }
  }

  // Upload car images
  Future<List<String>> _uploadImages(List<File> imageFiles) async {
    List<String> imageUrls = [];
    try {
      for (File imageFile in imageFiles) {
        String fileName = DateTime.now().millisecondsSinceEpoch.toString();
        Reference ref =
            FirebaseStorage.instance.ref().child('car_images/$fileName');
        UploadTask uploadTask = ref.putFile(imageFile);

        await uploadTask;
        String downloadUrl = await ref.getDownloadURL();
        imageUrls.add(downloadUrl);
      }
    } catch (e) {
      print('Erreur lors du téléchargement des images : $e');
    }
    return imageUrls;
  }

  // Add car with images
  final CollectionReference car =
      FirebaseFirestore.instance.collection('cars');

  Future<void> addCarWithImages(String id, String br, String c, String g, String m, String s, String r, String y, String a, String f, List<File> imageFiles) async {
    if (imageFiles.isEmpty) return;

    List<String> imageUrls = await _uploadImages(imageFiles);
    if (imageUrls.isNotEmpty) {
      await car.add({
        'car_id': id,
        'brand': br,
        'color': c,
        'gearbox': g,
        'model': m,
        'seat': s,
        'rental_price': r,
        'year': y,
        'available': a,
        'fuel_type': f,
        'image_urls': imageUrls,
      });
    } else {
      print('Erreur lors du téléchargement des images.');
    }
  }

  Future<void> _modifyCar(
    String id, 
    String br, 
    String c, 
    String g, 
    String m, 
    String s, 
    String r, 
    String y, 
    String a,
    String f,
    List<File> imageFiles
  ) async {
    if (imageFiles.isEmpty) {
      print('Aucune image à télécharger.');
      return;
    }

    try {
      // Téléchargement des images
      List<String> imageUrls = await _uploadImages(imageFiles);

      if (imageUrls.isNotEmpty) {
        // Référence au document spécifique dans Firestore
        DocumentReference carRef = FirebaseFirestore.instance.collection('cars').doc(id);

        // Mise à jour du document
        await carRef.update({
          'brand': br,
          'color': c,
          'gearbox': g,
          'model': m,
          'seat': s,
          'rental_price': r,
          'year': y,
          'available': a,
          'fuel_type': f,
          'image_urls': imageUrls,
        });

        print('Voiture modifiée avec succès.');
      } else {
        print('Erreur lors du téléchargement des images.');
      }
    } catch (e) {
      print('Erreur lors de la modification de la voiture: $e');
    }
  }

  // Add to favorites
  Future<void> addToFavorites(String carId) async {
    var userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(userId);
      await userDoc.update({
        'favorites': FieldValue.arrayUnion([carId]),
      });
    }
  }

  // Remove from favorites
  Future<void> removeFromFavorites(String carId) async {
    var userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(userId);
      await userDoc.update({
        'favorites': FieldValue.arrayRemove([carId]),
      });
    }
  }
}
