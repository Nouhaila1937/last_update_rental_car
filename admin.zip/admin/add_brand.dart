import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mon_projet2/services/firestore.dart';
import 'package:mon_projet2/admin/add_car.dart';

class Addbrand extends StatefulWidget {
  const Addbrand({super.key});

  @override
  _AddbrandState createState() => _AddbrandState();
}

class _AddbrandState extends State<Addbrand> {
  final FirestoreService firestoreService = FirestoreService();
  final TextEditingController brandIdController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController imageController = TextEditingController();
  File? _imageFile;

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _imageFile = File(pickedFile.path);
        imageController.text = pickedFile.path;
      } else {
        print('Aucune image sélectionnée.');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            bodySection(brandIdController, nameController, imageController),
            behind,
            headsection(context),
            addsection(context, firestoreService, brandIdController, nameController, imageController),
            secondary,
          ],
        ),
      ),
    );
  }

  Widget bodySection(TextEditingController brandIdController, TextEditingController nameController, TextEditingController imageController) {
    return Container(
      margin: const EdgeInsets.only(right: 20, top: 71),
      height: 650,
      width: 400,
      decoration: const BoxDecoration(
        color: Color.fromARGB(255, 0, 0, 0),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(72),
          bottomRight: Radius.circular(72),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 83, horizontal: 32),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const CupertinoSlidingSegmentedControlExample(),
              const SizedBox(height: 20),
              createTextField('Brand_id', brandIdController),
              createTextField('Name', nameController),
              createTextField('Image Path', imageController),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _pickImage,
                child: const Text('Pick an image'),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget addsection(BuildContext context, FirestoreService firestoreService, TextEditingController brandIdController, TextEditingController nameController, TextEditingController imageController) {
    return Column(
      children: [
        const SizedBox(height: 756),
        Container(
          margin: const EdgeInsets.only(left: 175),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              shadowColor: const Color.fromARGB(255, 200, 200, 200).withOpacity(1),
              elevation: 5,
              padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 15),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(13),
                  bottomRight: Radius.circular(13),
                  bottomLeft: Radius.circular(13),
                ),
              ),
            ),
            onPressed: () {
              firestoreService.addBrandWithImage(
                brandIdController.text,
                nameController.text,
                imageController.text,
              );
               // Vider les champs de texte
                  brandIdController.clear();
                  nameController.clear();
                  imageController.clear();
            },
            child: const Text(
              "Add",
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget createTextField(String labelText, TextEditingController controller) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      style: const TextStyle(color: Colors.white),
    );
  }

  Widget headsection(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 70, left: 40, bottom: 12),
      decoration: const BoxDecoration(
        color: Color.fromARGB(255, 255, 255, 255),
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(62)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, size: 30, color: Colors.black),
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/addcar');
            },
          ),
          const Text(
            "Add Brand",
            style: TextStyle(
              color: Colors.black,
              fontSize: 32,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget secondary = Container(
    width: 33,
    height: 40,
    margin: const EdgeInsets.only(top: 129.76, left: 340),
    decoration: const BoxDecoration(
      color: Colors.black,
      borderRadius: BorderRadius.only(topRight: Radius.circular(70)),
    ),
  );

  Widget behind = Container(
    width: 30,
    height: 26,
    margin: const EdgeInsets.only(top: 129, left: 346.5),
    decoration: const BoxDecoration(
      color: Color.fromARGB(255, 255, 255, 255),
    ),
  );
}

class CupertinoSlidingSegmentedControlExample extends StatefulWidget {
  const CupertinoSlidingSegmentedControlExample({super.key});

  @override
  _CupertinoSlidingSegmentedControlExampleState createState() =>
      _CupertinoSlidingSegmentedControlExampleState();
}

class _CupertinoSlidingSegmentedControlExampleState
    extends State<CupertinoSlidingSegmentedControlExample> {
  int? _selectedSegment = 0;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 171, 165, 165),
          borderRadius: BorderRadius.circular(25),
        ),
        padding: const EdgeInsets.all(10),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: CupertinoSlidingSegmentedControl<int>(
            groupValue: _selectedSegment,
            onValueChanged: (int? value) {
              setState(() {
                _selectedSegment = value;
                if (_selectedSegment == 1) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) =>  const Addcar()),
                  );
                }
              });
            },
            thumbColor: const Color.fromARGB(255, 217, 217, 217),
            children: const <int, Widget>{
              1: Padding(
                padding: EdgeInsets.symmetric(horizontal: 30),
                child: Text(
                  "Add car",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
              0: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "Add brand",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
            },
          ),
        ),
      ),
    );
  }
}
