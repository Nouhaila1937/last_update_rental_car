import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Modifycar extends StatefulWidget {
  final String carId;
  const Modifycar({super.key, required this.carId});

  @override
  _ModifycarState createState() => _ModifycarState();
}

class _ModifycarState extends State<Modifycar> {
  late Future<DocumentSnapshot> _carData;
  late TextEditingController brandController;
  late TextEditingController colorController;
  late TextEditingController gearboxController;
  late TextEditingController modelController;
  late TextEditingController seatController;
  late TextEditingController rentalPriceController;
  late TextEditingController yearController;
  late TextEditingController availableController;
  late TextEditingController fuelController; 

  Future<void> updateCar() async {
    try {
      await FirebaseFirestore.instance
          .collection('cars')
          .doc(widget.carId)
          .update({
            'brand': brandController.text,
            'color': colorController.text,
            'gearbox': gearboxController.text,
            'model': modelController.text,
            'seat': seatController.text,
            'rental_price': rentalPriceController.text,
            'year': yearController.text,
            'available': availableController.text,
            'fuel_type': fuelController.text,
          });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Car updated successfully'),
          backgroundColor: Colors.green,
        ),
      );
      // ignore: use_build_context_synchronously
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to update car'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _carData = FirebaseFirestore.instance
        .collection('cars')
        .doc(widget.carId)
        .get();

    // Initialize controllers
    brandController = TextEditingController();
    colorController = TextEditingController();
    gearboxController = TextEditingController();
    modelController = TextEditingController();
    seatController = TextEditingController();
    rentalPriceController = TextEditingController();
    yearController = TextEditingController();
    availableController = TextEditingController();
    fuelController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      body: FutureBuilder<DocumentSnapshot>(
        future: _carData,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Error loading car data'));
          }
          if (!snapshot.hasData) {
            return const Center(child: Text('No data found'));
          }

          final carData = snapshot.data!.data() as Map<String, dynamic>;

          // Update controllers with data from Firestore
          brandController.text = carData['brand'] ?? '';
          colorController.text = carData['color'] ?? '';
          gearboxController.text = carData['gearbox'] ?? '';
          modelController.text = carData['model'] ?? '';
          seatController.text = carData['seat'] ?? '';
          rentalPriceController.text = carData['rental_price'] ?? '';
          yearController.text = carData['year'] ?? '';
          availableController.text = carData['available'] ?? '';
          fuelController.text = carData['fuel_type'] ?? '';
         
          return SingleChildScrollView(
            child: Stack(
              children: [
                bodySection(
                  context,
                  brandController,
                  colorController,
                  gearboxController,
                  modelController,
                  seatController,
                  rentalPriceController,
                  yearController,
                  availableController,
                  fuelController,
                ),
                behind,
                headsection(context),
                modifySection(context,updateCar),
                secondary,
              ],
            ),
          );
        },
      ),
    );
  }
}

// Widget personnalisé pour l'en-tête
Widget headsection(BuildContext context) {
  return Container(
    padding: const EdgeInsets.only(top: 70, left: 18, bottom: 12),
    decoration: const BoxDecoration(
      color: Color.fromARGB(255, 255, 255, 255),
      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(62)),
    ),
    child: Row(
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back, size: 30, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        const Text(
          "Modify content",
          style: TextStyle(
            color: Colors.black,
            fontSize: 32,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    ),
  );
}

Widget secondary = Container(
  width: 33,
  height: 40,
  margin: const EdgeInsets.only(top: 129.76, left: 340),
  decoration: const BoxDecoration(
    color: Colors.black,
    borderRadius: BorderRadius.only(topRight: Radius.circular(70)),
  ),
);

Widget behind = Container(
  width: 30,
  height: 26,
  margin: const EdgeInsets.only(top: 129, left: 346.5),
  decoration: const BoxDecoration(
    color: Color.fromARGB(255, 255, 255, 255),
  ),
);

// Widget pour le corps de la page
Widget bodySection(
  BuildContext context,
  TextEditingController brandController,
  TextEditingController colorController,
  TextEditingController gearboxController,
  TextEditingController modelController,
  TextEditingController seatController,
  TextEditingController rentalPriceController,
  TextEditingController yearController,
  TextEditingController availableController,
  TextEditingController fuelController, 
) {
  return Container(
    margin: const EdgeInsets.only(right: 20, top: 71),
    height: 650,
    width: 400,
    decoration: const BoxDecoration(
      color: Color.fromARGB(255, 0, 0, 0),
      borderRadius: BorderRadius.only(
        bottomLeft: Radius.circular(72),
        bottomRight: Radius.circular(72),
      ),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 83, horizontal: 32),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            createTextField('Brand', brandController),
            createTextField('Color', colorController),
            createTextField('Gearbox', gearboxController),
            createTextField('Model', modelController),
            createTextField('Seat', seatController),
            createTextField('Rental price', rentalPriceController),
            createTextField('Year', yearController),
            createTextField('Available', availableController),
            createTextField('Fuel type', fuelController), 
            const SizedBox(height: 20),
          ],
        ),
      ),
    ),
  );
}

Widget createTextField(String labelText, TextEditingController controller) {
  return TextField(
    controller: controller,
    decoration: InputDecoration(
      labelText: labelText,
      labelStyle: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 20,
      ),
    ),
    style: const TextStyle(color: Colors.white),
  );
}

Widget modifySection(BuildContext context, Function updateCar) {
  return Column(
    children: [
      const SizedBox(height: 756),
      Container(
        margin: const EdgeInsets.only(left: 175),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            shadowColor:
                const Color.fromARGB(255, 200, 200, 200).withOpacity(1),
            elevation: 5,
            padding: const EdgeInsets.symmetric(horizontal: 70, vertical: 15),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(13),
                bottomRight: Radius.circular(13),
                bottomLeft: Radius.circular(13),
              ),
            ),
          ),
          onPressed: () => updateCar(),
          child: const Text(
            "Modify",
            style: TextStyle(
              fontSize: 18,
            ),
          ),
        ),
      ),
    ],
  );
}
