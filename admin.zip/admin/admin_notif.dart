import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AdminReservationsPage extends StatefulWidget {
  const AdminReservationsPage({super.key});

  @override
  _AdminReservationsPageState createState() => _AdminReservationsPageState();
}

class _AdminReservationsPageState extends State<AdminReservationsPage> {
  String _selectedReservationId = '';

  Future<String?> _getUserEmail(String userId) async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      return user?.email;
    } catch (e) {
      print("Erreur lors de la récupération de l'email : $e");
      return null;
    }
  }

  void _updateReservationStatus(String reservationId, String status) async {
    await FirebaseFirestore.instance.collection('reservations').doc(reservationId).update({
      'status': status,
    });
    setState(() {
      _selectedReservationId = reservationId;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Réservation mise à jour')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Toutes les Réservations')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('reservations').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Erreur: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text('Aucune réservation trouvée.'));
          }

          var reservations = snapshot.data!.docs;

          return ListView.builder(
            itemCount: reservations.length,
            itemBuilder: (context, index) {
              var reservation = reservations[index];
              var userId = reservation['userId'];
              var carId = reservation['carId'];
              var status = reservation['status']; // Récupérer le statut de la réservation

              return FutureBuilder(
                future: Future.wait([
                  _getUserEmail(userId),
                  FirebaseFirestore.instance.collection('cars').doc(carId).get(),
                ]),
                builder: (context, AsyncSnapshot<List> snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const ListTile(
                      title: Text("Chargement..."),
                    );
                  }

                  if (snapshot.hasError) {
                    return Center(child: Text('Erreur: ${snapshot.error}'));
                  }

                  var userEmail = snapshot.data?[0] ?? 'Email inconnu';
                  var carData = snapshot.data?[1]?.data() as Map<String, dynamic>? ?? {};

                  var carBrand = carData['brand'] ?? 'Marque inconnue';
                  var carModel = carData['model'] ?? 'Modèle inconnu';

                  // Changer la couleur de fond du ListTile en fonction du statut
                  Color tileColor = (status == 'pending') ? Colors.yellow[100]! : Colors.white;

                  return ListTile(
                    title: Text('Utilisateur: $userEmail'),
                    subtitle: Text('Voiture: $carBrand $carModel\nDate de début: ${reservation['startDate'].toDate().toString()}\nDate de fin: ${reservation['endDate'].toDate().toString()}'),
                    tileColor: tileColor, // Appliquer la couleur de fond
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.check),
                          onPressed: () => _updateReservationStatus(reservation.id, 'accepted'),
                        ),
                        IconButton(
                          icon: const Icon(Icons.cancel),
                          onPressed: () => _updateReservationStatus(reservation.id, 'rejected'),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
