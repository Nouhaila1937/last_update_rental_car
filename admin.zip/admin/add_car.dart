import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:mon_projet2/services/firestore.dart';
import 'add_brand.dart';

class Addcar extends StatefulWidget {
  const Addcar({super.key});

  @override
  _TestState createState() => _TestState();
}

class _TestState extends State<Addcar> {
  final List<File> _imageFiles = [];
  final _picker = ImagePicker();

  final TextEditingController carIdController = TextEditingController();
  final TextEditingController brandController = TextEditingController();
  final TextEditingController colorController = TextEditingController();
  final TextEditingController gearboxController = TextEditingController();
  final TextEditingController modelController = TextEditingController();
  final TextEditingController seatController = TextEditingController();
  final TextEditingController rentalPriceController = TextEditingController();
  final TextEditingController yearController = TextEditingController();
  final TextEditingController imageController = TextEditingController();
  final TextEditingController availableController = TextEditingController();
  final TextEditingController fuelController = TextEditingController();
  FirestoreService firestoreService = FirestoreService();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _imageFiles.add(File(pickedFile.path));
      } else {
        print('Aucune image sélectionnée.');
      }
    });
  }

  Future<void> _addCar() async {
      try {
    await firestoreService.addCarWithImages(
      carIdController.text,
      brandController.text,
      colorController.text,
      gearboxController.text,
      modelController.text,
      seatController.text,
      rentalPriceController.text,
      yearController.text,
      availableController.text,
      fuelController.text,
      _imageFiles,
    );

    // Vider les champs de texte et les images
    carIdController.clear();
    brandController.clear();
    colorController.clear();
    gearboxController.clear();
    modelController.clear();
    seatController.clear();
    rentalPriceController.clear();
    yearController.clear();
    availableController.clear();
    fuelController.clear();
    imageController.clear();
    setState(() {
      _imageFiles.clear();
    });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Car added successfully'),
          backgroundColor: Colors.green,
        ),
      );
      // ignore: use_build_context_synchronously
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to add car'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            bodySection(
              context,
              _imageFiles,
              _pickImage,
              _addCar,
              carIdController,
              brandController,
              colorController,
              gearboxController,
              modelController,
              seatController,
              rentalPriceController,
              yearController,
              availableController,
              fuelController,
              imageController,
            ),
            behind,
            headsection(context),
            addsection(context, _addCar),
            secondary,
          ],
        ),
      ),
    );
  }
}

// Widget personnalisé pour l'en-tête
Widget headsection(BuildContext context) {
  return Container(
    padding: const EdgeInsets.only(top: 70, left: 40, bottom: 12),
    decoration: const BoxDecoration(
      color: Color.fromARGB(255, 255, 255, 255),
      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(62)),
    ),
    child: Row(
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back, size: 30, color: Colors.black),
          onPressed: () {
              Navigator.pushNamed(context, '/crud');
          },
        ),
        const Text(
          "Add Car",
          style: TextStyle(
            color: Colors.black,
            fontSize: 32,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    ),
  );
}

// Fonction pour créer un TextField avec un style défini
Widget createTextField(String labelText, TextEditingController controller) {
  return TextField(
    controller: controller,
    decoration: InputDecoration(
      labelText: labelText,
      labelStyle: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 20,
      ),
    ),
    style: const TextStyle(color: Colors.white),
  );
}

// Widget pour le corps de la page
Widget bodySection(
  BuildContext context,
  List<File> imageFiles,
  Function pickImage,
  Function addCar,
  TextEditingController carIdController,
  TextEditingController brandController,
  TextEditingController colorController,
  TextEditingController gearboxController,
  TextEditingController modelController,
  TextEditingController seatController,
  TextEditingController rentalPriceController,
  TextEditingController yearController,
  TextEditingController availableController,
  TextEditingController fuelController,
  TextEditingController imageController,
) {
  return Container(
    margin: const EdgeInsets.only(right: 20, top: 71),
    height: 650,
    width: 400,
    decoration: const BoxDecoration(
      color: Color.fromARGB(255, 0, 0, 0),
      borderRadius: BorderRadius.only(
        bottomLeft: Radius.circular(72),
        bottomRight: Radius.circular(72),
      ),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 83, horizontal: 32),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const CupertinoSlidingSegmentedControlExample(),
            const SizedBox(height: 20),
            createTextField('Car_id', carIdController),
            createTextField('Brand', brandController),
            createTextField('Color', colorController),
            createTextField('Gearbox', gearboxController),
            createTextField('Model', modelController),
            createTextField('Seat', seatController),
            createTextField('Rental_price', rentalPriceController),
            createTextField('Year', yearController),
            createTextField('available', availableController),
            createTextField('fuel', fuelController),
            createTextField('Image', imageController),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => pickImage(),
              child: const Text('Select Image'),
            ),
            const SizedBox(height: 20),
            imageFiles.isNotEmpty
                ? Wrap(
                    spacing: 8.0,
                    runSpacing: 4.0,
                    children: imageFiles
                        .map((imageFile) => Image.file(
                              imageFile,
                              width: 100,
                              height: 100,
                              fit: BoxFit.cover,
                            ))
                        .toList(),
                  )
                : const Text('Aucune image sélectionnée.',
                    style: TextStyle(color: Colors.white)),
            const SizedBox(height: 20),
          ],
        ),
      ),
    ),
  );
}

Widget secondary = Container(
  width: 33,
  height: 40,
  margin: const EdgeInsets.only(top: 129.76, left: 340),
  decoration: const BoxDecoration(
    color: Colors.black,
    borderRadius: BorderRadius.only(topRight: Radius.circular(70)),
  ),
);

Widget behind = Container(
  width: 30,
  height: 26,
  margin: const EdgeInsets.only(top: 129, left: 346.5),
  decoration: const BoxDecoration(
    color: Color.fromARGB(255, 255, 255, 255),
  ),
);

Widget addsection(BuildContext context, Function addCar) {
  return Column(
    children: [
      const SizedBox(height: 756),
      Container(
        margin: const EdgeInsets.only(left: 175),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            shadowColor:
                const Color.fromARGB(255, 200, 200, 200).withOpacity(1),
            elevation: 5,
            padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 15),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(13),
                bottomRight: Radius.circular(13),
                bottomLeft: Radius.circular(13),
              ),
            ),
          ),
          onPressed: () => addCar(),
          child: const Text(
            "Add",
            style: TextStyle(
              fontSize: 18,
            ),
          ),
        ),
      ),
    ],
  );
}

class CupertinoSlidingSegmentedControlExample extends StatefulWidget {
  const CupertinoSlidingSegmentedControlExample({super.key});

  @override
  _CupertinoSlidingSegmentedControlExampleState createState() =>
      _CupertinoSlidingSegmentedControlExampleState();
}

class _CupertinoSlidingSegmentedControlExampleState
    extends State<CupertinoSlidingSegmentedControlExample> {
  int? _selectedSegment = 0;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 171, 165, 165),
          borderRadius: BorderRadius.circular(25),
        ),
        padding: const EdgeInsets.all(13),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: CupertinoSlidingSegmentedControl<int>(
            groupValue: _selectedSegment,
            onValueChanged: (int? value) {
              setState(() {
                _selectedSegment = value;
              });
              if (value == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Addbrand()),
                );
              } else if (value == 0) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Addcar()),
                );
              }
            },
            thumbColor: const Color.fromARGB(255, 217, 217, 217),
            children: const <int, Widget>{
              0: Padding(
                padding: EdgeInsets.symmetric(horizontal: 30),
                child: Text(
                  "Add car",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
              1: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "Add brand",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
            },
          ),
        ),
      ),
    );
  }
}
