import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:mon_projet2/admin/add_car.dart';
import 'package:mon_projet2/admin/modify.dart';
import 'dart:typed_data';
import 'package:mon_projet2/test.dart';

class Crud extends StatelessWidget {
  const Crud({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 5, 5, 5),
      appBar: AppBar(
        title: const Text("Admin Section"),
        backgroundColor: const Color.fromARGB(255, 35, 79, 234),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/notification');
            },
            icon: const Icon(
              Icons.notifications_active_rounded,
              color: Colors.white,
              size: 20,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [ 
          // notification(context),
          logoutSection(context),
          brandssection,
          availablesection,
        
        ],
      )),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const Addcar(),
            ),
          );
        },
        backgroundColor: const Color.fromARGB(255, 35, 79, 234),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

Future<Uint8List> removeBackground(String imageUrl) async {
  try {
    final response = await http.post(
      Uri.parse('https://api.remove.bg/v1.0/removebg'),
      headers: {
        'X-Api-Key': 'LFjrGfdzEe6PbsgiLMTE5h12', // Remplacez par votre clé API
      },
      body: {
        'image_url': imageUrl,
        'size': 'auto',
      },
    );

    if (response.statusCode == 200) {
      return response.bodyBytes;
    } else {
      // En cas d'erreur, essayez de retourner l'image originale
      final imageResponse = await http.get(Uri.parse(imageUrl));
      if (imageResponse.statusCode == 200) {
        return imageResponse.bodyBytes;
      } else {
        throw Exception('Failed to fetch original image');
      }
    }
  } catch (e) {
    // Gérer les exceptions en essayant d'obtenir l'image originale
    final imageResponse = await http.get(Uri.parse(imageUrl));
    if (imageResponse.statusCode == 200) {
      return imageResponse.bodyBytes;
    } else {
      throw Exception('Failed to fetch original image');
    }
  }
}

Future<void> deleteBrand(String brandId, BuildContext context) async {
  try {
    await FirebaseFirestore.instance.collection('brand').doc(brandId).delete();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Brand deleted successfully'),
        backgroundColor: Colors.green,
      ),
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Failed to delete brand'),
        backgroundColor: Colors.red,
      ),
    );
  }
}

Future<void> deleteCar(String carId, BuildContext context) async {
  try {
    await FirebaseFirestore.instance.collection('cars').doc(carId).delete();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Car deleted successfully'),
        backgroundColor: Colors.green,
      ),
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Failed to delete car'),
        backgroundColor: Colors.red,
      ),
    );
  }
}

// Widget notification (BuildContext context) {
//    return Container(
    
//   child: IconButton(
//     onPressed: () async {
//       // Rediriger vers la page de connexion ou d'accueil
//       Navigator.pushReplacementNamed(context, '/notification');
//     },
//     icon: const Icon(
//       Icons.notifications_active_rounded, // Icône de déconnexion
//       color: Color.fromARGB(255, 255, 255, 255),
//       size: 20,
//     ),
//   ),
// );
// }

Widget logoutSection(BuildContext context) {
  return Container(
    margin: const EdgeInsets.only(top: 80, bottom: 12),
    width: 360,
    height: 60,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(23),
    ),
    child: Row(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(left: 10.0),
          child: IconButton(
            onPressed: () async {
              // Code de déconnexion
              await FirebaseAuth.instance.signOut();
              // Rediriger vers la page de connexion ou d'accueil
              Navigator.pushReplacementNamed(context, '/homepage1');
            },
            icon: const Icon(
              Icons.logout, // Icône de déconnexion
              color: Color.fromARGB(255, 81, 80, 80),
              size: 20,
            ),
          ),
        ),
        const Expanded(
          child: Text(
            "Logout", // Texte affiché à la place du placeholder de recherche
            style: TextStyle(color: Colors.black, fontSize: 20),
          ),
        ),
      ],
    ),
  );
}

Widget brandssection = Container(
  margin: const EdgeInsets.all(20),
  child: Column(
    children: [
      const Align(
        alignment: Alignment.topLeft,
        child: Text(
          "Brands",
          style: TextStyle(
            color: Colors.white,
            fontSize: 29,
            fontFamily: 'Ledger',
          ),
        ),
      ),
      const SizedBox(height: 20),
      FutureBuilder<QuerySnapshot>(
        future: FirebaseFirestore.instance.collection('brand').get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final brands = snapshot.data!.docs;

          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: brands.map((brand) {
                final brandData = brand.data() as Map<String, dynamic>;
                return Column(
                  children: [
                    FutureBuilder<Uint8List>(
                      future: removeBackground(brandData['logo_url']),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.done) {
                          if (snapshot.hasError) {
                            return Container(
                              width: 80,
                              height: 80,
                              margin: const EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 230, 8, 8),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(14),
                                child: Image.network(
                                  brandData[
                                      'logo_url'], // Affiche l'image d'origine en cas d'erreur
                                  fit: BoxFit.contain,
                                ),
                              ),
                            );
                          }
                          return Container(
                            width: 80,
                            height: 80,
                            margin: const EdgeInsets.only(right: 10),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 230, 8, 8),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: Image.memory(
                                snapshot.data!,
                                fit: BoxFit.contain,
                              ),
                            ),
                          );
                        } else {
                          return Container(
                            width: 80,
                            height: 80,
                            margin: const EdgeInsets.only(right: 10),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 230, 8, 8),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Center(
                                child: CircularProgressIndicator()),
                          );
                        }
                      },
                    ),
                    const SizedBox(
                        height:
                            10), // Ajouter un espace entre l'image et l'icône
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.white),
                      onPressed: () {
                        deleteBrand(brand.id, context);
                      },
                    ),
                  ],
                );
              }).toList(),
            ),
          );
        },
      ),
    ],
  ),
);

Widget availablesection = Container(
  margin: const EdgeInsets.all(20),
  child: Column(
    children: [
      const Align(
        alignment: Alignment.topLeft,
        child: Text(
          "Available cars",
          style: TextStyle(
            color: Colors.white,
            fontSize: 29,
            fontFamily: 'Ledger',
          ),
        ),
      ),
      const SizedBox(height: 20),
      StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('cars').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Text('Something went wrong');
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Text('No cars available');
          }

          final cars = snapshot.data!.docs;
          return ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: cars.length,
            itemBuilder: (context, index) {
              final car = cars[index];
              final carData = car.data() as Map<String, dynamic>;
              return Column(
                children: [
                  FutureBuilder<Uint8List>(
                    future: removeBackground(carData['image_urls'][0]),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.done) {
                        if (snapshot.hasError) {
                          return Container(
                            margin: const EdgeInsets.only(bottom: 20),
                            width: 320,
                            height: 170,
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 217, 217, 217),
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(22),
                              child: Image.network(
                                carData['image_urls'][
                                    0], // Affiche l'image d'origine en cas d'erreur
                                fit: BoxFit.cover,
                              ),
                            ),
                          );
                        }
                        return Container(
                          margin: const EdgeInsets.only(bottom: 20),
                          width: 320,
                          height: 170,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 217, 217, 217),
                            borderRadius: BorderRadius.circular(22),
                          ),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: <Widget>[
                              Positioned(
                                top: -40,
                                left: (330 - 230) / 2,
                                child: Image.memory(
                                  snapshot.data!,
                                  width: 230,
                                  height: 100,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomRight,
                                child: Padding(
                                  padding: const EdgeInsets.all(0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              Test(carId: car.id),
                                        ),
                                      );
                                    },
                                    style: ButtonStyle(
                                      backgroundColor:
                                          WidgetStateProperty.all<Color>(
                                              const Color.fromARGB(
                                                  255, 35, 79, 234)),
                                      foregroundColor:
                                          WidgetStateProperty.all<Color>(
                                              Colors.white),
                                      shape: WidgetStateProperty.all<
                                          RoundedRectangleBorder>(
                                        const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(14),
                                            bottomRight: Radius.circular(22),
                                          ),
                                        ),
                                      ),
                                    ),
                                    child: const Text('Details'),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        '${carData['brand']} ${carData['model']} ${carData['year']}', // Concatenate values
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        'DH ${carData['rental_price']} /day',
                                        style: const TextStyle(fontSize: 16),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                top: 80,
                                right: 10,
                                child: Row(
                                  children: <Widget>[
                                    IconButton(
                                      icon: const Icon(Icons.edit),
                                      onPressed: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                Modifycar(carId: car.id),
                                          ),
                                        );
                                      },
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete),
                                      onPressed: () {
                                        // Action de suppression
                                        deleteCar(car.id, context);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      } else {
                        return Container(
                          margin: const EdgeInsets.only(bottom: 20),
                          width: 320,
                          height: 170,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 217, 217, 217),
                            borderRadius: BorderRadius.circular(22),
                          ),
                          child:
                              const Center(child: CircularProgressIndicator()),
                        );
                      }
                    },
                  ),
                  const SizedBox(
                      height:
                          40), // Ajustez la taille de l'espace selon vos besoins
                ],
              );
            },
          );
        },
      ),
    ],
  ),
);

